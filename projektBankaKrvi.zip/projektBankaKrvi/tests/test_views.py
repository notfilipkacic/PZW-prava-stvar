from django.test import TestCase, Client
from django.urls import reverse
from main.models import Donacija,DonacijskaKartica,Donator,KrvnaGrupa,Primatelj,SpremnikKrvi, Primanje

################################################################
# radi 
################################################################

class TestViews(TestCase):

    def setUp(self):
        self.client = Client()
        self.homepage_url = reverse('main:pocetna')
        self.donator = reverse('main:donator')
        self.primatelj = reverse('main:primatelj')
        self.donacije = reverse('main:donacije')
        self.donacijskakartica = reverse('main:donacijskakartica')
        self.krvnagrupa = reverse('main:krvnagrupa')
        self.spremnikkrvi = reverse('main:spremnikkrvi')
        self.primanje = reverse('main:primanje')
        

        self.kg1 = KrvnaGrupa.objects.create(
            kg = 'B'
        )

        self.donator1 = Donator.objects.create(
            ime = 'TestName',
            prezime = 'TestSurr',
            krvna_grupa = self.kg1,
        )

    def test_project_donator_GET(self):
        client = Client()

        response = client.get(self.donator)

        self.assertEquals(response.status_code, 200)
        self.assertTemplateUsed(response, 'donator_list.html')

    def test_project_primatelj_GET(self):
        client = Client()

        response = client.get(self.primatelj)

        self.assertEquals(response.status_code, 200)
        self.assertTemplateUsed(response, 'primatelj_list.html')

    def test_project_donacija_GET(self):
        client = Client()

        response = client.get(self.donacije)

        self.assertEquals(response.status_code, 200)
        self.assertTemplateUsed(response, 'donacije_list.html')

    def test_project_donacijskakartica_GET(self):
        client = Client()

        response = client.get(self.donacijskakartica)

        self.assertEquals(response.status_code, 200)
        self.assertTemplateUsed(response, 'donacijske_kartice_list.html')

    def test_project_krvnagrupa_GET(self):
        client = Client()

        response = client.get(self.krvnagrupa)

        self.assertEquals(response.status_code, 200)
        self.assertTemplateUsed(response, 'krvnagrupa_list.html')

    def test_project_spremnikkrvi_GET(self):
        client = Client()

        response = client.get(self.spremnikkrvi)

        self.assertEquals(response.status_code, 200)
        self.assertTemplateUsed(response, 'spremnik_list.html')

    def test_project_primanje_GET(self):
        client = Client()

        response = client.get(self.primanje)

        self.assertEquals(response.status_code, 200)
        self.assertTemplateUsed(response, 'primanja_list.html')