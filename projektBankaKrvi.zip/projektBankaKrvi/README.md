# ZADATAK: Izrada modela i predložaka (pogleda) za web aplikaciju ili uslugu ovisno o odabranoj temi. Zadatak se radi samostalno ili u grupama po dvoje. Potrebno je započeti izradu web aplikacije ili usluge i u danom roku predati aplikaciju ili uslugu koja ima izrađene modele i predloške (poglede). Ovisno o točnosti i potpunosti izrađenih modela i predložaka (pogleda), može se ostvariti do 20 bodova.
# TEMA: Sustav upravljanja bankom krvi.
# IMENA STUDENATA: Filip Kačić, Nadia Vidas
